
from datetime import datetime
import os
from pathlib import Path

import pefile
import peutils
import ssdeep
import typer

from .utils import get_filepaths


USER_DB_TXT = os.path.join(
    os.path.dirname(os.path.realpath(__file__)),
    'userdb.txt',
)


class PEInfo:
    def __init__(self, path: Path):
        self.path = path
        self.pe = pefile.PE(path)

    @property
    def fuzzy_hash(self):
        return ssdeep.hash_from_file(str(self.path))

    @property
    def imphash(self):
        return self.pe.get_imphash()

    # fix + tests
    def is_section_suspicious(self, section):
        pass

    @property
    def sections(self):  # add sections hashes here too? + suspiciounes
        pass

        # # move this to sections
        # @property
        # def is_packed(self):
        #     # packeet vs suspicious
        #     # and per section vs the whole file.
        #     for section in self.pe.sections:
        #         section.get_entropy()
        #         if section.SizeOfRawData == 0 or (
        #                 section.get_entropy() > 0 and section.get_entropy() < 1) or section.get_entropy() > 7:
        #             suspicious = True
        #         else:
        #             suspicious = False

    # fix + tests
    @property
    def imports(self):
        rv = {}
        if hasattr(self.pe, 'DIRECTORY_ENTRY_IMPORT'):
            for entry in self.pe.DIRECTORY_ENTRY_IMPORT:  # pylint: disable=no-member
                rv[entry.dll] = []
                for import_ in entry.imports:
                    import_name = import_.name if import_.name is not None else "ord(%s)" % (
                        str(import_.ordinal))  # whats the meaning of ordinal
                    rv[entry.dll].append(import_name)
        return rv

    def print_imports(self):
        typer.echo("\nImports:\n")
        for lib in self.imports:
            typer.secho(f"{lib.decode('utf8')}", fg=typer.colors.BRIGHT_CYAN)
            for import_ in self.imports[lib]:
                typer.secho(f"\t{import_.decode('utf8')}",
                            fg=typer.colors.CYAN)

    @property
    def exports(self):  # TODO: testing for exports
        if hasattr(self.pe, 'DIRECTORY_ENTRY_EXPORT'):
            return [export.name for export in self.pe.DIRECTORY_ENTRY_EXPORT.symbols]  # pylint: disable=no-member
        return []

    # fix + tests

    @property
    def built_with(self):
        from pdb import set_trace
        # set_trace()

        signatures = peutils.SignatureDatabase(USER_DB_TXT)
        # Why this is returning none?...same file from peid on windows is working?
        # or why its returning something else than the pe program in windows?
        matched = signatures.match(self.pe)
        return matched[0] if matched else ""

    @property
    def raw_size(self):
        # move to sections also?
        pass
    # fix + tests

    @property
    def virtual_size(self):
        # move to sections also?
        # safe?
        pass

    @property
    def compilation_date(self):
        return datetime.utcfromtimestamp(
            self.pe.FILE_HEADER.TimeDateStamp).strftime('%Y-%m-%d %H:%M:%S')  # pylint: disable=no-member

    # fix + tests

    @ property
    def resources(self):  # do i really need it?
        pass
     # fix + tests

    @ property
    def subsystem(self):
        return pefile.SUBSYSTEM_TYPE[self.pe.OPTIONAL_HEADER.Subsystem]

    def print_pe_info(self, show_filename: bool = True):
        # from pdb import set_trace
        # set_trace()
        # REfactor priting?. Refactor more dynamic?
        # Fix the whole function..
        # Fisrt fix all properties functionality and then maybe refactor this method or the whole class

        if show_filename:
            typer.secho(self.path.name, fg=typer.colors.RED)

        # if self.is_packed:
        #     typer.secho("\nIs Packed", fg=typer.colors.GREEN)
        # else:
        #     typer.secho("\nIs Not Packed", fg=typer.colors.GREEN)
        val_color = typer.colors.CYAN
        typer.echo(
            f"\nFuzzy hash: {typer.style(self.fuzzy_hash, fg=val_color)}")

        # typer.echo(f"\nRaw Size: {typer.style(self.raw_size, fg=val_color)}")
        # typer.echo(
        #     f"\nVirtual Size: {typer.style(self.virtual_size, fg=val_color)}")
        typer.echo(f"\nImphash: {typer.style(self.imphash, fg=val_color)}")
        typer.echo(
            f"\nBuilt with: {typer.style(self.built_with, fg=val_color)}")
        typer.echo(
            f"\nCompilation date: {typer.style(self.compilation_date, fg=val_color)}")
        typer.echo(f"\nSubsystem: {typer.style(self.subsystem, fg=val_color)}")

        self.print_imports()

        exports_string = "\n".join(self.exports)
        typer.echo(f"\nExports:\n {typer.style(exports_string, fg=val_color)}")

        # typer.echo(f"\nSections: {typer.style(self.sections, fg=val_color)}")
        # typer.echo(f"\nResources: {typer.style(self.resources, fg=val_color)}")


def get_pe_info(path: Path):
    """
    Return a list of pe_info objects for every file in the path.
    """
    rv = []
    for filepath in get_filepaths(path):
        try:
            rv.append(PEInfo(filepath))
        except pefile.PEFormatError as ex:
            typer.secho(
                f"Can't analyze {filepath}", fg=typer.colors.RED)
            if path.is_dir():
                typer.secho(f"---", fg=typer.colors.MAGENTA)
    return rv
