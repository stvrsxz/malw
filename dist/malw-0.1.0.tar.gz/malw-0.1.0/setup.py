# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['malw']

package_data = \
{'': ['*']}

install_requires = \
['pefile>=2019.4.18,<2020.0.0',
 'python-magic>=0.4.22,<0.5.0',
 'ssdeep>=3.4,<4.0',
 'tabulate>=0.8.9,<0.9.0',
 'typer>=0.3.2,<0.4.0']

entry_points = \
{'console_scripts': ['malw = malw.malw:app']}

setup_kwargs = {
    'name': 'malw',
    'version': '0.1.0',
    'description': 'A Simple Malware Analyzer with Python',
    'long_description': 'TODO: refactor this in the end\n\nA Malware Analyzer with Python and Typer\n\n(A simplistic project with the purpose of combining some new python features, the typer cli framework and malware analysis)\n\n---\n\n## Installation:\n\n(TODO: Publish to pypi?)\n\n(TODO: Make project public) From Github with pip:\n\n`pip3 install --user https://github.com/0xstvrs/malw/raw/master/dist/malw-0.1.0-py3-none-any.whl`\n\nLocally with pip:\n\n`git clone https://github.com/0xstvrs/malw.git`\n\n`cd malw`\n\n`pip3 install --user dist/malw-0.1.0-py3-none-any.whl`\n\n(Optional)\n\nWhen installed:\n\nInstall completion:\n\n`malw --install-completion`\n\nRemove installed with pip:\n\n`pip3 uninstall malw`\n\nLocally within a virtual env:\n\n`pip3 install poetry`\n\n`git clone https://github.com/0xstvrs/malw.git`\n\n`cd malw`\n\n`poetry install`\n\n`poetry shell`\n\n`malw`\n\n(Optional)\n\n`poetry build`\nand then install the generated .whl file (see step with the .whl installation)\n\nUpgrade:\n\n`pip3 install malw -U`\n\n\nTesting: (use a make file? see floss)\nCreate the pe file:\n`sudo apt-get install mingw-w64`\n`x86_64-w64-mingw32-gcc -o tests/files/pe.exe tests/files/pe_source.c`\n\nPacked:\n`upx -o tests/files/pe_packed.exe tests/files/pe.exe`\n\n\nQuick: (maybe remove this):\n`rm tests/files/*.exe; x86_64-w64-mingw32-gcc -o tests/files/pe.exe tests/files/pe_source.c; upx -o tests/files/pe_packed.exe tests/files/pe.exe`\n\n\nTroubleshooting:\n- malw uses python-magic for file type detection. If you have problems with it, first check the prerequisites for using this package https://github.com/ahupp/python-magic#installation\n- if the ssdeep is failing, try to install: `sudo apt install libffi-dev libfuzzy-dev libfuzzy2`\n- TODO: Python version?',
    'author': '0xstvrs',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
